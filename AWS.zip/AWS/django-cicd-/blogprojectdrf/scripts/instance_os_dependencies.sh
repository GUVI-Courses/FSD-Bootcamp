#!/usr/bin/env bash

sudo apt install -y python3-pip
sudo apt install -y nginx
sudo apt install -y virtualenv