import React from 'react'
import BookDetails from '../components/BookDetails'

function ViewBook() {
  return (
    <div>
        <h2>View Book</h2>
        <BookDetails/>
    </div>
  )
}

export default ViewBook