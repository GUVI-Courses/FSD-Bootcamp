# mylist=[1,2,3,4,5,1.2547,"bowl","bat",True,["apple","orange"]]
# print(mylist)
# print(mylist[5])
# print(mylist[9])
# print(type(mylist[9]))
# print(mylist[9][1])
# print(mylist[-2])

# list inbuilt methods  

# mynum=[1,2,3,4,9,8,7,6,5]
# mychar=['c','d','a','b','D','A']
# mywords=['prompt','loyal','care','good','APPle','Orange']
# # mynum.sort()
# # mychar.sort()
# # mywords.sort()
# # print(mynum)
# # print(mychar)
# # print(mywords)
# mynum.append(10)
# print(mynum)
# print(mynum.index(4))

# print(len(mywords))
# mywords.insert(3,'guvi')
# print(mywords)

# mywords.pop()
# print(mywords)

# mywords.remove("APPle")
# print(mywords)

# mychar2=mychar.copy()
# print(mychar2)

# print(mychar2.count('a'))

# mylist=["employeename","employeesalary","company",2023,50000]
# for i in mylist:
#     if i=="company":
#         continue
#     print(i)

'''

Exercise 1: Sum of Numbers numbers = [1, 2, 3, 4, 5]
Write a Python program that calculates the sum of all numbers in a list.
Exercise 2: Even Numbers numbers = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]
Write a Python program that prints all the even numbers from a list.
Exercise 3: List Reversal 
mylist = [1, 2, 2, 3, 4, 2, 5, 2] Write a Python program that reverses a given list.
Write a Python program that counts the number of times a specific element appears in a list.


'''