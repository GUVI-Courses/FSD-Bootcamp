import React from 'react'

function Navbar() {
  return (
    <div> GUVI</div>
  )
}

export default Navbar