# mystr='Welcome to Python Programming for FSD'
# print(mystr)
# mystr="Welcome to Python Programming for FSD"
# print(mystr)
# mystr='''Welcome to Python Programming for FSD'''
# print(mystr)
mystr="guvi is the Best Training platform for beginners & Professionals"
print("Uppercase :",mystr.upper())
print("Lowercase :",mystr.lower())
print("Capitalise :",mystr.capitalize())
print("count :",mystr.count("a"))
print("count :",mystr.count("beginners"))
print("count :",mystr.count("ark"))
print("count :",mystr.find("ark"))
print("count :",mystr.find("&"))
print("startswith :",mystr.startswith("guvi"))
print("startswith :",mystr.endswith("guvi"))
print("length :",len(mystr))
print(mystr.isalpha())
print(mystr.isalnum())
print(mystr.replace("Professionals","Intermediate Folks"))
print(mystr.split())
mystr=mystr.replace("Professionals","Intermediate Folks")
print(mystr)