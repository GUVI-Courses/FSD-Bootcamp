import React,{useState,useEffect,useMemo} from 'react'

function UseMemoHook() {
    const [number,setNumber]=useState(0);
    const [dark,setDark]=useState(false);

    const doubleNumber=useMemo(()=>{
        return slowFunction(number)
    },[number])

    // const themeStyle = useMemo(()=>{
        
    //        return {
    //         backgroundColor: dark ? 'black' : 'white',
    //         color: dark ? 'white' : 'black',
    //        }
        
    
    // },[dark])

    const themeStyle = 
        
           {
            backgroundColor: dark ? 'black' : 'white',
            color: dark ? 'white' : 'black',
           }
        
  
    
    useEffect(()=>{
        console.log('theme changed')
    },[themeStyle])



  return (
    <div>
        UseMemoHook

    <input type="number" value={number} onChange={e=>setNumber(parseInt(e.target.value))} />

    <button onClick={()=>setDark((prevDark)=>!prevDark)}>Change Theme</button>
    <div style={themeStyle}>{doubleNumber}</div>


    </div>
  )
}

function slowFunction(num){
    for(let i=0; i<100000000;i++){}
    console.log('okk')
    return num*2
}

export default UseMemoHook