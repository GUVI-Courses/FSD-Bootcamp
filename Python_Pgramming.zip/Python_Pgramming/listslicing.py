# mylist=['anees','meghana','amrutha','aneeqah','aadithyaa','harshith']
# mylist.sort()
# print(mylist)
# mylist.remove('anees')
# print(mylist)




# print("positive slicing")
# myslice=[1,2,4,6,7,9,10]
# print(myslice[:]) #1,2,4,6,7,9,10
# print(myslice[1:]) ##2,4,6,7,9,10
# print(myslice[:5]) #1,2,4,6,7
# print(myslice[3:7]) #6,7,9,10

# print("negative slicing")
# myslice=[1,2,4,6,7,9,10]
# print(myslice[-5:]) #4,6,7,9,10
# print(myslice[1:-3]) #2,4,6
# print(myslice[:-1]) #1,2,4,6,7,9
# print(myslice[-5:-2]) #4,6,7

# myslice=[1,2,4,6,7,9,10]
# print(myslice[::2]) #1,4,7,10
# print(myslice[1:4:2]) #2,6
# print(myslice[::-1]) # 10,9,7,6,4,2,1
# print(myslice[::-2]) #10,7,4,1



'''List Slicing 
mylist=[23,4,5,6,7,8,1,2,3,9,0,122,10,2,3,4,3,3,2]
write a python program to slice the mylist
a)print elements [1,2,3] using slicing concept
b)print elements [9,0,122,10,2,3] 
c)print elements [8,1,2,3,9,0,122,10,2,3,4,3,3,2] 
d)print elements [10,2,3,4,3,3,2]
e)print elements [10,3,3,2]
f)print elements [6,8,2,9]
g)print elements [1,0,3,2]

using negative slice 
e)print elements [10,3,3,2]
f)print elements [6,8,2,9]
g)print elements [1,0,3,2]
h)print elements [1,2,3,9,0,122]'''