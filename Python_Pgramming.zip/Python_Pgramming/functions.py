# def function_name():
#     print('i am a funtion')

# function_name()    


# company="infosys"
# def employeeDetails():
#     # company="guvi"
#     print("rohan works at",company)

# print("outside the function",company)
# employeeDetails()
# employeeDetails()
# employeeDetails()

# def employeeDetails(ename='xyz',erole='fsd',esalary=30000):
#     company="guvi"
#     print("\nEmployee name is ",ename,"\nEmployee role is ",erole,"\nEmployee salary is ",esalary)
#     print("He works at",company)

# employeeDetails("anees","developer")