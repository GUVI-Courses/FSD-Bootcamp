// var name;
// name='guvi'
// name='india'
// var since=1999
// console.log(name,since)

// // es6
// // let,const 
// let y;
// let employee='rohan'
// let age=23
// let city='bangalore'
// // let name;
// name='ark'
// console.log(employee,age,city)


// const x={
//     x:7
// };

// console.log(x)

// const name='ark';

// {
// let name='xyx';
// console.log(name)
// }

// const citys=['kolkata','hydrabad'];
// {
//     console.log('inside the block ', citys)
//     let city='Bangalore';
//     console.log(city)
//     // let citys=['mumbai','chennai']
//     // console.log(citys)
// }

// console.log('outside the block',citys)
// // console.log('outside the block',city) not accessable

// var means if you try to change the value of varaiable it will getchange

// const means if you try to change the value it will not change empty declaration is prohibitted

// let means in block level { } you can resuse varaibale but we cannot access outside tee block