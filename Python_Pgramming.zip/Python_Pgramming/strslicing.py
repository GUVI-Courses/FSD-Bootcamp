mystr="My name is Guvi"
# print(mystr[start:end-1])
# print(mystr[:])
# print(mystr[2:9])
# print(mystr[:9])


# # negative slicing
# print(len(mystr))
# print(mystr[-15:-5]) # mystr[start:end-1] [-15:-5-1] [-15:-6]
# print(mystr[-15:])

# #stepsize # print(mystr[start:end-1:stepsize-1])
# print(mystr[::2])
# print(mystr[2:15:5])
# print(mystr[1:15:5])

print(mystr[::-1])
print(mystr[::-2])