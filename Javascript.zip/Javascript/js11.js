// If
let a=true;
if(a){
    console.log('yes')
}

// let age = 18;
// if (age >= 18) {
//     console.log("You are an adult.");
// }


// if (condition) {
//     // code block to be executed if the condition is true
// } else {
//     // code block to be executed if the condition is false
// }


// let age = 25;
// if (age >= 18) {
//     console.log("You are an adult.");
// } else {
//     console.log("You are a minor.");
// }


// else if 

// if (condition1) {
//     // code block to be executed if condition1 is true
// } 
// else if (condition2) {
//     // code block to be executed if condition2 is true
// }
// else if (condition3) {
//     // code block to be executed if condition2 is true
// }
// else if (condition4) {
//     // code block to be executed if condition2 is true
// }
// else if (condition5) {
//     // code block to be executed if condition2 is true
// }
//  else {
//     // code block to be executed if all conditions are false
// }

// let score=95;
// if(score>=90){
//     console.log('A')
// }
// else if(score>=80){
//     console.log('B')
// }
// else if(score>=70){
//     console.log('C')
// }
// else if(score>=60){
//     console.log('D')
// }
// else{
//     console.log('Fail')
// }


// switch

// switch(expression) {
//     case value1:
//         // code block to be executed if expression === value1
//         break;
//     case value2:
//         // code block to be executed if expression === value2
//         break;
//     // additional cases here
//     default:
//         // code block to be executed if none of the cases match
// }


// let day=5;
// switch(day){
//     case 1:
//         console.log('Monday')
//         break;
//     case 2:
//         console.log("tuesday")
//         break
//     case 3:
//         console.log("wednesday")
//         break
//     case 4:
//         console.log("thursday")
//         break
//     case 5:
//         console.log("friday")
//         break
//     case 6:
//         console.log("saturday")
//         break
//     default:
//         console.log("Sunday")
//         break
// }

// Ternary operator

// condition ? expression1 : expression2

// let age=15;

// let canVote= (age>=18)?"He can Vote":"He Cannot Vote"
// console.log(canVote)


// for(let i=1;i<=10;i++){
//     if(i==5){
//         continue
//     }
//     console.log(i)
// }