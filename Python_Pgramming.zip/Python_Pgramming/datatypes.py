firstName="GUVI"
since=2014
print(firstName,since)
print(type(firstName),type(since))

mylist=[1,2,3]
print(mylist)
print(type(mylist))



myset={1,2,3,1,2,3}
print(myset)
print(type(myset)) 


tup=(1,2,3)
print(type(tup))

mydict={
    "name":"Guvi",
    "since":2014
}


print(mydict)
print(type(mydict))


# mybool=True
# mybool2=False
# print(type(mybool))
# print(type(mybool2))

'''
a=None
print(type(a))

salary=15000.254
print(type(salary))
'''