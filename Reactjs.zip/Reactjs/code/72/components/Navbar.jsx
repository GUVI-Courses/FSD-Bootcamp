import React from 'react'

function Navbar() {
  return (
    <div>Navbar GUVI</div>
  )
}

export default Navbar