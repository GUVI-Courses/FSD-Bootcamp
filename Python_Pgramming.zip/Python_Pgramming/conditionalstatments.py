# a="guvi"
# b="guvi"
# if(a!=b):
#     print("i am inside if block")
#     print(1)
#     print(2)
#     print(3)
# else:
#     print("i am else part")
#     print(4)
#     print(5)
#     print(6)


# print(" i am outside else if")

# a=10
# b=20
# if(a<b): #true
#     print("I am if block")
#     print("Yes a is less than b")
#     print("thank you")


# print("i am outside the if block")
# sum=a+b
# print("sum is" ,sum)

# if(12<3):
#     print("12>3")
# elif(3<2):
#     print("3>2")
# elif(10>20):
#     print("10>20")
# else:
#     print("else")

'''1. Write a program to validate a person can vote or not
*take the age as input from the user
if age is less than 18 print he cannot vote
if age is greater than 18 print he can vote
if age is greater than 90 print please stay at home
if age is 18 than  print please make the voter id '''
# age=int(input("Enter your age:\n"))

# if(age<18):
#     print("You Cannot Vote")

# elif(age>18 and age<=90):
#     print("You can vote")

# elif(age>90):
#     print("please stay at home")

# elif(age==18):
#     print("please make the voter id")

# else:
#     print("stoopp")


if(False):
    print("i am if")
    if(True):
        print("i am first if of if")
    else:
        print("i am else of first if")

        if(True):
            print("True")

else:
    print(" i am else")
    if(False):
        print("i am else if of if")

    elif(True):
        print("i am el if")
    else:
        print("i am else of first else")

        if(True):
            print("True")    