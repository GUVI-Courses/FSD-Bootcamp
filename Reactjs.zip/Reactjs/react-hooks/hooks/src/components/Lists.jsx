import React, { useEffect, useState } from "react";

function Lists({ getItems }) {
  const [items, setItems] = useState([]);
  useEffect(() => {
    setItems(getItems());
    console.log('calling')
  }, [getItems]);

  return items.map(item=><div>{item}</div>)
}

export default Lists;
