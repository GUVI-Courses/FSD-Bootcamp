console.log('js-1 in external file')
console.error('no error')
console.warn('warning')
console.table({
    "name":"guvi",
    "since":2014
})