employeename=input("Enter the employee name :\n")
employeesalary=float(input("Enter the employee salary :\n"))
employeePhone=int(input("Enter the employee Phone :\t"))
employeeAddress=str(input("Enter the employee Address :\t"))
print("Employee Name is ",employeename,type(employeename))
print("Employee salary is ",employeesalary,type(employeesalary))
print("Employee Phone is ",employeePhone,type(employeePhone))
print("Employee Adresss is ",employeeAddress,type(employeeAddress))


'''

1) write a python program to evaluate below String
a) Add the string1 "Zen Classes" & string2 "GUVI"  and print the new string   
b) Find the length of the string and reverse it 
'''
'''
1) 
write a python program to evaluate below string 
mystr= "GUVI is an IIT-M & IIM-A incubated Ed-tech company“  
a) print "incubated " using positive slicing & negative slicing  
b) print "company" using negative slicing  
c) print "G n" using stepindex  
d) print "Gy"    using stepindex
'''

# 2) Take a inputs  from user and evaluate the expression. 
# a) Take the Students name. 
# b) Take the student english marks, maths, science, social, kannada & hindi 
# c) add the total marks  
# d) print average 
# e) add languages marks (english, kannada, hindi)and print average 
# f) add the core subjects (maths, science and social) and print average

# 1





