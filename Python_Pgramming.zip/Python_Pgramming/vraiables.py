'''
''' ''' - multi line comment
# - single line comment
# varaibles
print('Data types')
'''
print("Variables")
name="Guvi"
since=2014
print(name,since)
country="INDIA"
print(country)

# rules of declaring the varaiables

# 1name="guvi" 
_name="guvi"
name1="guvi"
f1=10
# first name="guvi"
firstname="guvi"
# ()-=%$*$)="guvi"

# use cases for declaring the varaiables
firstName="Anees"   
FirstName="Anees"   
firstname="Anees"
FIRSTNAME="ANEES"   
first_name="Anees"
