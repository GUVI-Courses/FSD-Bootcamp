str1="anees"
salary=2397
address="bangalore"
print("my name is ",str1,"my salary is ",salary,"i stay at",address)
print(f"my name is {str1} \nmy salary is {salary}\ni stay at {address}")